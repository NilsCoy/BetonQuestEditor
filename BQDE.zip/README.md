# Beton Quest Diologe Editor
This program was created by one enthusiast in order to simplify the work with dialogues and quests in the beton quest plugin. 

It may not be as good as it may seem, but it has already helped me out many times before going on github, so I decided to share it with everyone.

To find out how the program works, go to the wiki: https://github.com/NilsCoy/BetonQuest-DiologeEditor/wiki
